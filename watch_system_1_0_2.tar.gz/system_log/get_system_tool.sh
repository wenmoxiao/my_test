#! /bin/bash
if [ $# != 0 ] && [ $# != 1 ]; then
  exit 0
fi

old_cron_line="\*\/3 \* \* \* \* cd \/data\/system_log\/; sh get_system_tool.sh >\/dev\/null 2>&1"
cron_line="\*\/1 \* \* \* \* cd \/data\/system_log\/; sh get_system_tool.sh >\/dev\/null 2>&1"

# 
do_type=0
if [ $# == 1 ];then
 do_type=$1
fi

grep -F "${old_cron_line}" /var/spool/cron/root >/dev/null
if ! [ $? -gt 1 ]; then
        sed -i "/${old_cron_line}/d" /var/spool/cron/root
        crontab /var/spool/cron/root
fi

if (( $do_type == 1 )); then
  set_cron=$(cat /var/spool/cron/root |grep get_system_tool)
  if [ "$set_cron" = "" ]; then
    echo  "*/1 * * * * cd /data/system_log/; sh get_system_tool.sh >/dev/null 2>&1"  >> /var/spool/cron/root
  fi
   crontab /var/spool/cron/root
fi

if (( $do_type == 2 )); then
  grep -F "${cron_line}" /var/spool/cron/root >/dev/null
  if ! [ $? -gt 1 ]; then
        sed -i "/${cron_line}/d" /var/spool/cron/root
        crontab /var/spool/cron/root
  fi
fi

if (( $do_type == 0 )); then
  grep -F "${cron_line}" /var/spool/cron/root >/dev/null
  if ! [ $? -gt 1 ]; then
        sed -i "/${cron_line}/d" /var/spool/cron/root
        crontab /var/spool/cron/root
  fi
  set_cron=$(cat /var/spool/cron/root |grep get_system_tool)
  if [ "$set_cron" = "" ]; then
    echo  "*/1 * * * * cd /data/system_log/; sh get_system_tool.sh >/dev/null 2>&1"  >> /var/spool/cron/root
  fi
   crontab /var/spool/cron/root 
fi


log_file_path="/data/system_log/log"
if [ ! -d "$log_file_path" ]; then  
   mkdir "$log_file_path"  
fi

all_pid=$(ps -aux |grep get_system_info | grep -v "grep" | awk '{print $2}')
echo $all_pid
for p in $all_pid
do
  kill -9 $p
done


all_pid=$(ps -aux |grep get_system_perf | grep -v "grep" | awk '{print $2}')
echo $all_pid
for p in $all_pid
do
  kill -9 $p
done


if (( $do_type != 2 ));then
   sh ./get_system_info.sh &
   sh ./get_system_perf.sh &
fi





