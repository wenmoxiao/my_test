#! /bin/bash
if [ $# != 0 ] && [ $# != 1 ]; then
  echo "./get_system_info.sh interval_time"
  exit 0
fi

log_file_num=7
interval_time=10
log_file="/data/system_log/log/system_log"

if [ $# == 2 ];then
 interval_time=$1
fi


function update_log
{
  file_name=$log_file"_"$log_file_num
  if [ -f $file_name ]; then
     rm -rf $file_name
  fi
  for ((idx = $(($log_file_num - 1)); idx > 0; idx -=1));
  do
    file_name_f=$log_file"_"$idx
	file_name_to=$log_file"_"$(($idx + 1))
    if [ -f $file_name_f ]; then
	 mv $file_name_f $file_name_to
	fi
  done
  
  file_name=$log_file
  if [ -f $file_name ]; then
     mv $file_name $file_name"_1"
  fi
}


now_day=`date +%d`
#echo $now_day
if [ -f $log_file ];then
  file_day=`ls -l $log_file|awk '{print $7}'`
  if (( $file_day != $now_day ));then
    update_log
  fi
fi

# get commond
num_index=0
export -a commond_list
commond_file="./system_info_commond.conf"
while read line
do
  #echo $num_index $line
  commond_list[$num_index]=$line
  ((num_index++))
done < $commond_file



while((1))
do
  cur_day=`date +%d`
  if (( $now_day != $cur_day )); then
   echo "change_next_day"$now_day" "$cur_day >> $log_file
   update_log
   #sed -i '1,'"$num_index"'d' /var/system_log/system_log
   now_day=$cur_day
  fi 
  
  echo "-----top-----st ">> $log_file
  top -n 1 -b|head -15|tail -8 >> $log_file
  echo "-----ps-----st ">> $log_file
  ps -aux |sort -rn -k +4 |head -5 >> $log_file
   
  for ((idx = 0; idx < num_index; idx +=1));
  do
    echo "-----"${commond_list[$idx]}"-----st " >> $log_file
	${commond_list[$idx]} >> $log_file
  done
  
  sleep $interval_time

done
