#! /bin/bash
if [ $# != 0 ] && [ $# != 1 ]; then
  exit 0
fi

old_cron_line="\*\/3 \* \* \* \* cd \/data\/system_log\/; sh get_system_tool.sh >\/dev\/null 2>&1"
cron_line="\*\/1 \* \* \* \* cd \/data\/system_log\/; sh get_system_tool.sh >\/dev\/null 2>&1"
cron_file=/var/spool/cron/root
fuben_file=/var/spool/cron/system_log


# 
do_type=0
if [ $# == 1 ];then
 do_type=$1
fi

crontab -l >> $fuben_file

function do_crontab
{
   rm -rf $cron_file
   mv $fuben_file $cron_file
   crontab $cron_file
}


old_3=$(cat $fuben_file | grep "*/3 * * * * cd /data/system_log/; sh get_system_tool.sh >/dev/null 2>&1")
if [ "$old_3" != "" ]; then
        sed -i "/${old_cron_line}/d" $fuben_file
fi

if (( $do_type == 1 )); then
  set_cron=$(cat $fuben_file |grep get_system_tool)
  if [ "$set_cron" = "" ]; then
    echo  "*/1 * * * * cd /data/system_log/; sh get_system_tool.sh >/dev/null 2>&1"  >> $fuben_file
  fi
   do_crontab
fi

if (( $do_type == 2 )); then
  del_cron=$(cat $fuben_file |grep get_system_tool)
  if [ "$del_cron" != "" ]; then
        sed -i "/${cron_line}/d" $fuben_file
        do_crontab
  fi
fi

if (( $do_type == 0 )); then
  crontab -l | grep -F "${cron_line}" $fuben_file >/dev/null
  if ! [ $? -gt 1 ]; then
        set_cron=$(cat $fuben_file |grep get_system_tool)
        if [ "$set_cron" = "" ]; then
           echo  "*/1 * * * * cd /data/system_log/; sh get_system_tool.sh >/dev/null 2>&1"  >> $fuben_file
           do_crontab 
        fi
  fi
fi

if [ -f $fuben_file ];then
  rm -rf $fuben_file
fi

log_file_path="/data/system_log/log"
if [ ! -d "$log_file_path" ]; then  
   mkdir "$log_file_path"  
fi

all_pid=$(ps -aux |grep get_system_info | grep -v "grep" | awk '{print $2}')
echo $all_pid
for p in $all_pid
do
  kill -9 $p
done


all_pid=$(ps -aux |grep get_system_perf | grep -v "grep" | awk '{print $2}')
echo $all_pid
for p in $all_pid
do
  kill -9 $p
done



echo $perf_info

if (( $do_type != 2 ));then
   sh ./get_system_info.sh &
   perf_info=$(rpm -qa | grep perf |grep -v "gperf" |sum |awk '{print $2}')
   if (( 0 != $perf_info));then
     sh ./get_system_perf.sh &
   fi
fi





